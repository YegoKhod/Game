﻿using UnityEngine;
using System.Collections;

public class portal : MonoBehaviour {

	public bool AStart = false;
}
